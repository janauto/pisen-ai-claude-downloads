# Windows 发行包的上游组件

- 内核为 MetaCubeX 发布的原版 Mihomo v1.19.34。下载和对应源码见[上游发行页](https://github.com/MetaCubeX/mihomo/releases/tag/v1.19.34)，许可证见同目录 `LICENSE-mihomo.txt`。
- 国内 IP 分流数据库为 MetaCubeX/meta-rules-dat 的 `country.mmdb`，取自 2026-11-25 的上游发行。下载和生成数据的项目见[发行页](https://github.com/MetaCubeX/meta-rules-dat/releases)和[源码](https://github.com/MetaCubeX/meta-rules-dat)，许可证见同目录 `LICENSE-meta-rules-dat.txt`。
- Windows TUN 使用 [Wintun 0.14.1](https://www.wintun.net/) 官方签名驱动，许可证见同目录 `LICENSE-wintun.txt`。
